export default function Home() {
    return (
        <div className="font-display text-9xl font-bold text-text tracking-tight shrink-0 text-center flex items-center justify-center h-screen">
            <span className="text-9xl text-accent">Fair</span>
            Drop<span className="text-accent">.</span>
        </div>
    )
}